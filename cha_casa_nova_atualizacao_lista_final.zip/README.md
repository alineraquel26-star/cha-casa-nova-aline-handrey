ATUALIZAÇÃO — PAINEL DOS NOIVOS

1) No Supabase SQL Editor, execute supabase_atualizacao.sql.
2) No Supabase > Authentication > Users, crie o usuário (e-mail + senha) para o painel.
3) Depois, conecte este código ao projeto atual do Vercel via GitHub para manter o mesmo endereço.
4) O painel ficará em:
   https://SEU-ENDERECO.vercel.app/admin.html
5) Convidados continuam usando a página principal e não veem os nomes.
6) No painel, os noivos veem convidado/presente/data e podem cancelar.

Não coloque nenhuma Secret/Service Role key no navegador.
