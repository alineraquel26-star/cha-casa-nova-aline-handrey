const ITEMS=[
  {id:"item-1",name:"3 Descansos de Panela",price:"R$20–40",url:"https://s.shopee.com.br/5LC0wzUy2d"},
  {id:"item-2",name:"Kit Peneiras",price:"R$20–40",url:"https://s.shopee.com.br/2BEzD53gSs"},
  {id:"item-3",name:"Rodo de Pia",price:"R$20–40",url:"https://s.shopee.com.br/6fhOXXRnco"},
  {id:"item-4",name:"Porta Detergente Preto",price:"R$20–40",url:"https://s.shopee.com.br/5forLet1S0"},
  {id:"item-5",name:"Cuscuzeira",price:"R$20–40",url:"https://s.shopee.com.br/2gBFo8ggQm"},
  {id:"item-6",name:"Kit Utensílios de Bambu",price:"R$20–40",url:"https://s.shopee.com.br/905JKIBfbp"},
  {id:"item-7",name:"2 Espátulas Pretas",price:"R$20–40",url:"https://s.shopee.com.br/gQBOs6I31"},
  {id:"item-8",name:"5 Potes de Vidro",price:"R$20–40",url:"https://s.shopee.com.br/9zxqW3jDZK"},
  {id:"item-9",name:"Porta Sal Grande",price:"R$20–40",url:"https://s.shopee.com.br/40gdOGWQ0i"},
  {id:"item-10",name:"1 Escorredor de Macarrão",price:"R$20–40",url:"https://s.shopee.com.br/40gdMwdDEv"},
  {id:"item-11",name:"2 Jarras de Vidro",price:"R$20–40",url:"https://s.shopee.com.br/9zxqVrAGHH"},
  {id:"item-12",name:"Tábua de Corte",price:"R$20–40",url:"https://s.shopee.com.br/7VGVXrIAZ4"},
  {id:"item-13",name:"2 Formas de Bolo",price:"R$20–40",url:"https://s.shopee.com.br/7AdfDreMxk"},
  {id:"item-14",name:"Conjunto de Xícaras",price:"R$20–40",url:"https://s.shopee.com.br/8fSSvtGUFN"},
  {id:"item-15",name:"6 Canecas Caneladas",price:"R$20–40",url:"https://s.shopee.com.br/1BMRzyqo8C"},
  {id:"item-16",name:"Jogo de Panos de Prato Atoalhado",price:"R$20–40",url:"https://s.shopee.com.br/4VctyOAmPD"},
  {id:"item-17",name:"2 Moedores Sal e Pimenta",price:"R$20–40",url:"https://s.shopee.com.br/3g3mzIpIyw"},
  {id:"item-18",name:"6 Copos Canelados",price:"R$20–40",url:"https://s.shopee.com.br/AUu774wQB4"},
  {id:"item-19",name:"Kit Porta Papel",price:"R$41–60",url:"https://s.shopee.com.br/2LYPOmrfLb"},
  {id:"item-20",name:"Porta Temperos",price:"R$41–60",url:"https://s.shopee.com.br/1LfsGt2VGX"},
  {id:"item-21",name:"Bandeja de Bambu",price:"R$41–60",url:"https://s.shopee.com.br/2gBFnBmqhz"},
  {id:"item-22",name:"Jogo de Tigelas",price:"R$41–60",url:"https://s.shopee.com.br/AAHGjQiBS2"},
  {id:"item-23",name:"Kit Cumbuca",price:"R$41–60",url:"https://s.shopee.com.br/3VkMsLEcen"},
  {id:"item-24",name:"Kit de Talheres",price:"R$41–60",url:"https://s.shopee.com.br/4qFkNZYyCR"},
  {id:"item-25",name:"Conjunto de Facas",price:"R$41–60",url:"https://s.shopee.com.br/80CmA3fYBc"},
  {id:"item-26",name:"Potes Mantimentos",price:"R$41–60",url:"https://s.shopee.com.br/9Ki9niZLy7"},
  {id:"item-27",name:"Cesto Organizador",price:"R$41–60",url:"https://s.shopee.com.br/AUu77SHn5g"},
  {id:"item-28",name:"Kit 3 Travessas",price:"R$41–60",url:"https://s.shopee.com.br/2gBFngnWdZ"},
  {id:"item-29",name:"Jogo de Bowl",price:"R$41–60",url:"https://s.shopee.com.br/2BEzD0eyCd"},
  {id:"item-30",name:"4 Pratos Rasos",price:"R$61–80",url:"https://s.shopee.com.br/1BMS5sJM7Q"},
  {id:"item-31",name:"Escorredor",price:"R$61–80",url:"https://s.shopee.com.br/905JPgqoCq"}
  {id:"item-32",name:"Jogo de Sobremesa",price:"R$20–40",url:"https://s.shopee.com.br/4qFnMX04Iv"},
];
const url=window.SUPABASE_URL,key=window.SUPABASE_ANON_KEY;
const reserved=new Set();let selected=null;
const list=document.getElementById('list'),status=document.getElementById('status'),search=document.getElementById('search'),price=document.getElementById('price'),modal=document.getElementById('modal'),guest=document.getElementById('guest'),msg=document.getElementById('msg');
const H=(extra={})=>Object.assign({apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'},extra);
async function loadReservations(){
 try{let r=await fetch(`${url}/rest/v1/reservation_status?select=item_id`,{headers:H()});
 if(!r.ok){console.warn(await r.text());throw Error()}; (await r.json()).forEach(x=>reserved.add(x.item_id));
 status.textContent=`${ITEMS.filter(x=>!reserved.has(x.id)).length} disponível(is) • ${ITEMS.length} presente(s)`;
 render();}catch(e){status.textContent='Não foi possível carregar as reservas.';}
}
function render(){const q=search.value.toLowerCase().trim(),p=price.value;list.innerHTML='';
ITEMS.filter(i=>(!q||i.name.toLowerCase().includes(q))&&(!p||i.price===`R${p}`)).forEach(i=>{const done=reserved.has(i.id),c=document.createElement('article');c.className='card';c.innerHTML=`<div class="icon">💝</div><h3>${i.name}</h3><div class="price">${i.price}</div>${done?'<div class="reserved">✅ Já escolhido<br><small>Presente reservado</small></div>':'<button>🎁 Reservar presente</button>'}<a href="${i.url}" target="_blank" rel="noopener">Ver modelo na Shopee ↗</a>`;if(!done)c.querySelector('button').onclick=()=>openModal(i);list.appendChild(c)})}
function openModal(i){selected=i;guest.value='';msg.textContent='';msg.className='msg';document.getElementById('modalTitle').textContent=i.name;modal.classList.remove('hidden');guest.focus()}
function closeModal(){modal.classList.add('hidden');selected=null}document.getElementById('close').onclick=closeModal;modal.onclick=e=>{if(e.target===modal)closeModal()};
document.getElementById('reserve').onclick=async()=>{const name=guest.value.trim();if(!name||!selected){msg.textContent='Digite seu nome.';msg.className='msg err';return}msg.textContent='Reservando...';
try{let r=await fetch(`${url}/rest/v1/reservations`,{method:'POST',headers:H({Prefer:'return=minimal'}),body:JSON.stringify({item_id:selected.id,item_name:selected.name,guest_name:name})});if(r.status===409)throw Error('DUP');if(!r.ok)throw Error(await r.text());reserved.add(selected.id);closeModal();render();status.textContent='Presente reservado com sucesso! 💕';}catch(e){if(e.message==='DUP'){reserved.add(selected.id);msg.textContent='Esse presente acabou de ser reservado por outra pessoa.'}else msg.textContent='Não foi possível reservar. Tente novamente.';msg.className='msg err';render()}};
search.oninput=render;price.onchange=render;document.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{price.value=b.dataset.p;render()});loadReservations();
