-- Execute este SQL no Supabase SQL Editor ANTES de publicar a atualização.
-- Ele protege os nomes dos convidados: o público só consulta os IDs reservados.
alter table public.reservations enable row level security;

drop policy if exists "Public can view reservations" on public.reservations;
drop policy if exists "Public can reserve gifts" on public.reservations;

create policy "Public can reserve gifts"
on public.reservations for insert to anon
with check (char_length(trim(guest_name)) between 1 and 80);

create policy "Authenticated admins can view reservations"
on public.reservations for select to authenticated
using (true);

create policy "Authenticated admins can delete reservations"
on public.reservations for delete to authenticated
using (true);

create or replace view public.reservation_status as
select item_id from public.reservations;

grant select on public.reservation_status to anon, authenticated;

-- IMPORTANTE:
-- No Supabase, crie um usuário em Authentication > Users com o e-mail e senha
-- que você usará no /admin.html.
-- O usuário autenticado poderá ver/cancelar reservas; convidados não verão nomes.
