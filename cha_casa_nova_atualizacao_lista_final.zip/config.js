window.SUPABASE_URL = "https://tawgiixpqirmeqwstiyw.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_D2hYVxnUZ09TfpqWuq8p1w_CH2a6-zh";
